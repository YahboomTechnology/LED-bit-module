#ifndef __DZ_H
#define __DZ_H	 

#include <stdbool.h>
#include "stm32f10x.h"
 
 
#ifndef __HT16K33_H
#define __HT16K33_H 

#include "stdlib.h"	
#include "stm32f10x.h"


#define SCL_GPIO_PORT    	GPIOB		              /* GPIO�˿� */
#define SCL_GPIO_CLK 	    RCC_APB2Periph_GPIOB		/* GPIO�˿�ʱ�� */
#define SCL_GPIO_PIN			GPIO_Pin_10			        

#define SDA_GPIO_PORT    	GPIOB		              /* GPIO�˿� */
#define SDA_GPIO_CLK 	    RCC_APB2Periph_GPIOB		/* GPIO�˿�ʱ�� */
#define SDA_GPIO_PIN		  GPIO_Pin_11		        
		 


#define HT16K33_SCL_L 		 GPIO_ResetBits(SCL_GPIO_PORT,SCL_GPIO_PIN)
#define HT16K33_SCL_H 		 GPIO_SetBits(SCL_GPIO_PORT,SCL_GPIO_PIN)//SCL

#define HT16K33_SDA_L 		 GPIO_ResetBits(SDA_GPIO_PORT,SDA_GPIO_PIN)//SDA
#define HT16K33_SDA_H 		 GPIO_SetBits(SDA_GPIO_PORT,SDA_GPIO_PIN)

//Ji2c��VCC/�ߵ�ƽ 

#define HT16K33_ADDRESS 0xE0

// Commands
#define HT16K33_ON              0x21  // 0=off 1=on
#define HT16K33_STANDBY         0x20  // bit xxxxxxx0


// bit pattern 1000 0xxy
// y    =  display on / off
// xx   =  00=off     01=2Hz     10=1Hz     11=0.5Hz
#define HT16K33_DISPLAYON       0x81
#define HT16K33_DISPLAYOFF      0x80
#define HT16K33_BLINKON0_5HZ    0x87
#define HT16K33_BLINKON1HZ      0x85
#define HT16K33_BLINKON2HZ      0x83
#define HT16K33_BLINKOFF        0x81

//#define HT16K33_DIM 0xE0|0x00 // Set dim from 0x00 (1/16th duty ccycle) to 0x0F (16/16 duty cycle)
#define HT16K33_DIM 0xE0|0x00

// bit pattern 1110 xxxx
// xxxx    =  0000 .. 1111 (0 - F)
#define HT16K33_BRIGHTNESS      0xE0
#define Brilliance      			  8  //�������� 0-15
extern unsigned int buffer[4];

void HT16K33_GPI0_Init(void);
void I2C_Start(void);
void I2C_Stop(void);
void I2C_WaitAck(void); //�������źŵĵ�ƽ
void Send_Byte(u8 dat);
void writeCmd(unsigned char cmd);
void writeDat(unsigned char addr,unsigned char dat);
void brightness(unsigned char val);
void displayOn(void);
void displayClear(void);
void reset(void);
void display_num(unsigned char Place,unsigned int dat);
void Left_Shift(uint8_t *Pdat,uint8_t Num);
void display_num1(unsigned char Place,unsigned int dat);
#endif
		 				    
#endif
