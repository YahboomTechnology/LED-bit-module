#ifndef __DELAY_H
#define __DELAY_H	 




void DelayInit();
void delay_ms(unsigned int ms);
void DelayMs(unsigned int nms);










#endif
