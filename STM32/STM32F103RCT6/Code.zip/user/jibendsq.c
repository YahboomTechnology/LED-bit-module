#include  "jibendsq.h"

void nvic_config(void)

{


}



void TIM6_CONFIG(void)
	
{
		nvic_config();
	
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6,ENABLE);
	TIM_TimeBaseInitTypeDef tim_li;
	tim_li.TIM_ClockDivision = TIM_CKD_DIV1;
	tim_li.TIM_Prescaler=71;
	tim_li.TIM_CounterMode=TIM_CounterMode_Up;
	tim_li.TIM_Period=9999;
	
	
	TIM_TimeBaseInit(TIM6,&tim_li);
	
	TIM_ClearFlag(TIM6,TIM_IT_Update);
	
	TIM_ITConfig(TIM6,TIM_IT_Update,ENABLE);
	TIM_Cmd(TIM6,ENABLE);

	//RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6,DISABLE);
	
	
	
}

//float kp = 10.0f, ki = 0;
//int16_t PID_realize1(int16_t target,int16_t current) 
//{ 
//  static float err = 0.0f, last_err = 0.0f;
//	static int16_t output = 0;
//	err = (int16_t)( target - current );
//	output += kp * ( err - last_err ) + ki * err;
//	last_err = err;
//	return (output); 
//}
