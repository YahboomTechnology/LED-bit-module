#ifndef __JBDSQ_H
#define	__JBDSQ_H

#include "stm32f10x.h"

void TIM6_CONFIG(void);
void nvic_config(void);

int16_t PID_realize1(int16_t target,int16_t current);


#endif 