#include "usart.h" 
#include "GPIO.h"
#include "stdlib.h"
#include "stm32f10x.h"
#include "string.h"

enum{
  enSTOP = 0,
  enRUN,
  enBACK,
  enLEFT,
  enRIGHT,
	beerout,
	ultra,
	oledshowip,

}CarState;

extern uint8_t g_Request_Flag ;
#define USART_REC_LEN  			200  
	void USART_Config(void)
  {
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
		GPIO_InitTypeDef   gpio_li;
		USART_InitTypeDef  USART_LI;
		NVIC_InitTypeDef  nvic_li;
		
		gpio_li.GPIO_Pin=GPIO_Pin_9;
		gpio_li.GPIO_Mode=GPIO_Mode_AF_PP;
		gpio_li.GPIO_Speed=GPIO_Speed_50MHz;
		GPIO_Init(GPIOA,&gpio_li);
		
		gpio_li.GPIO_Pin=GPIO_Pin_10;
		gpio_li.GPIO_Mode=GPIO_Mode_IN_FLOATING;
		GPIO_Init(GPIOA,&gpio_li);
		
		
		USART_LI.USART_BaudRate=115200;
		USART_LI.USART_WordLength=USART_WordLength_8b;
		USART_LI.USART_StopBits=USART_StopBits_1;
		USART_LI.USART_Parity=USART_Parity_No;
		USART_LI.USART_HardwareFlowControl=USART_HardwareFlowControl_None;
		USART_LI.USART_Mode=USART_Mode_Tx|USART_Mode_Rx;
		USART_Init(USART1,&USART_LI);
				
		nvic_li.NVIC_IRQChannel=USART1_IRQn;
	  nvic_li.NVIC_IRQChannelPreemptionPriority=0;
	  nvic_li.NVIC_IRQChannelSubPriority=0;
	  nvic_li.NVIC_IRQChannelCmd=ENABLE;
	  NVIC_Init(&nvic_li);
				
	  USART_ITConfig(USART1,USART_IT_RXNE,ENABLE);
		USART_Cmd(USART1,ENABLE);
		 
				
  }
	
u16 i=0; 
u8 ch[5];
u8 a;
char *b;
int cAa[4] = {0};
void USART1_IRQHandler(void)                	//
	{
				u8 res;
	if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)  //�����ж�(���յ������ݱ�����0x0d 0x0a��β)
		{
					res =USART_ReceiveData(USART1);

					if(res==0xB1)
					{
						GPIO_ResetBits(GPIOC,GPIO_Pin_13);
					}
//	//����
//					if(res==0xBB)
//					{
//					GPIO_SetBits(GPIOB,GPIO_Pin_13);
//					}
//	//ǰ			
//					if(res==0xB2)
//					{
//						Car_Stop();
//						g_Request_Flag=0;
//						Car_Run(4200);
//					}
//	//��
//					if(res==0xB3)
//					{
//						Car_Stop();
//						g_Request_Flag=0;
//						Car_Back(4200);	
//					}
//	//��
//					if(res==0xB4)
//					{
//						Car_Stop();
//						g_Request_Flag=0;
//						Car_Left(4200);
//					}
//	//��
//					if(res==0xB5)
//					{
//						Car_Stop();
//						g_Request_Flag=0;
//						Car_Right(4200);
//					}
//	//���� 
//					if(res==0xA1)
//					{
//						Car_Stop();
//						g_Request_Flag=1;
//					}
//					
//					if(res==0xAA)
//					{
//						Car_Stop();
////						GPIO_SetBits(GPIOB,GPIO_Pin_13);
//						a=1;
//						if(a==1)  //�����ж�(���յ������ݱ�����0x0d 0x0a��β)
							{
//								b =USART_ReceiveData(USART1);
//								IpToInt(b,strlen(b),cAa);
//								for(int i = 0;i < 4;i++)
////									OLED_ShowNum(10,5,cAa[i],4,16);
//							}
//					}
					
					
			}
				}
			 
			 USART_ClearITPendingBit(USART1,USART_IT_RXNE);
//		if((USART_RX_STA&0x8000)==0)//����δ���
//			{
//			if(USART_RX_STA&0x4000)//���յ���0x0d
//				{
//				if(Res!=0x0a)USART_RX_STA=0;//���մ���,���¿�ʼ
//				else USART_RX_STA|=0x8000;	//��������� 
//				}
//			else //��û�յ�0X0D
//				{	
//				if(Res==0x0d)USART_RX_STA|=0x4000;
//				else
//					{
//					USART_RX_BUF[USART_RX_STA&0X3FFF]=Res ;
//					USART_RX_STA++;
//					if(USART_RX_STA>(USART_REC_LEN-1))USART_RX_STA=0;//�������ݴ���,���¿�ʼ����	  
//					}		 
//				}
//			}   		 
//     } 

	}
	
	void Usart_SendByte( USART_TypeDef * pUSARTx, uint8_t ch)
  {
      USART_SendData(USART1,ch);
		  while (USART_GetFlagStatus(USART1,USART_FLAG_TXE)==RESET);
   }

  void Usart_SendString( USART_TypeDef * pUSARTx, char *str)
  {
		  
    uint8_t a=0;
		do
		{
			Usart_SendByte(USART1,*(str+a));
			a++;
		}while(*(str+a)!='\0');
		
		while (USART_GetFlagStatus(USART1,USART_FLAG_TC)==RESET)
		{}
  }
int  fputc(int ch,FILE *f)
	
{
   USART_SendData(USART1,(uint8_t) ch);
	 while(USART_GetFlagStatus(USART1,USART_FLAG_TXE)==RESET);
	
	 return (ch);


}

int fgetc(FILE *f)
{
  while(USART_GetFlagStatus(USART1,USART_FLAG_RXNE)==RESET);
	return (int)USART_ReceiveData(USART1);

}

//ip��ַ
void IpToInt(char* pBuffer,int len,int* pArr)
{
		char* pCur = pBuffer;
		int i = 0;
		int k = 0;
		pArr[i] = atoi(pCur);

		while(k++ < len)
		{
		if(*pCur == '.')
		{
		pArr[++i] = atoi(pCur + 1);
		}
		pCur++;

		}
}

//int _tmain(int argc)
//{
//char* ip = "10.34.243.148";
//int arr[4] = {0};
//IpToInt(ip,strlen(ip),arr);

//for(int i = 0;i < 4;i++)
//printf("arr[%d]:%d \n",i,arr[i]);

//return 0;
//}
